from pathlib import Path
import base64, re
root = Path(__file__).resolve().parents[1]
html = (root / "index.html").read_text()
payload = re.search(r'<script id="coastData" type="application/octet-stream">([^<]+)</script>', html).group(1)
out = Path(__file__).parent / "sunshine-coast.json.gz"
out.write_bytes(base64.b64decode(payload))
print("Extracted the complete included database:", out)
